import React from 'react'

function ListAllReportedPost() {
  return (
    <div>ListAllReportedPost</div>
  )
}

export default ListAllReportedPost