import React from 'react'
import AddProduct from "../../../../components/Ecommerce/Product/AddNewProduct"
function AddProducts() {
  return (
    <AddProduct/>
  )
}

export default AddProduct