export default function disableEdit() {
  alert('You can not edit it in demo');
  return;
}
